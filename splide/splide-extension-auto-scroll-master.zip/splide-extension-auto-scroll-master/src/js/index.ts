export { AutoScroll } from './extensions';
export type { AutoScrollComponent } from './extensions';