export const I18N = {
  startScroll: 'Start auto scroll',
  pauseScroll: 'Pause auto scroll',
};